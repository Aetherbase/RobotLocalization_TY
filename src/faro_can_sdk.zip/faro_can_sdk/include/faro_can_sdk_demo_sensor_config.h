/***********************************************************************
 *
 *  Copyright (c) 2017 - 2018 ANTZER TECH CO., LTD.
 *  All Rights Reserved
 *
 ************************************************************************/

// the configured options and settings for faro_can_sdk_demo_sensor
#define FARO_CAN_SDK_DEMO_SENSOR_VERSION_MAJOR 3
#define FARO_CAN_SDK_DEMO_SENSOR_VERSION_MINOR 1
#define FARO_CAN_SDK_DEMO_SENSOR_VERSION_PATCH 16
#define FARO_CAN_SDK_DEBUG 1
